/* automatically generated from makefile: make version */
#define VERSION    "2.5.1 (02 April 2007)"
#define LASTMOD    "Mon Apr  2 15:32:49 CEST 2007"
