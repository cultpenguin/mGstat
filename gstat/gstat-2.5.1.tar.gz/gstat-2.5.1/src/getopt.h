int getopt(int argc, char *argv[], const char *options);
extern char *optarg;
extern int optind, opterr, optopt;
