int ossfim(int argc, char *argv[]);
