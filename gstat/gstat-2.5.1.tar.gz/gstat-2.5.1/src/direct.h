double valid_direction(DPOINT *p, int symmetric, const DATA *d);
void set_direction_values(double a, double b, double t_h, double t_v);
