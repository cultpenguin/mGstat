void cross_valid(DATA **data);
