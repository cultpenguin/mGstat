DATA *block_discr(DATA *d, const DPOINT *block, const DPOINT *where);
void reset_block_discr(void);
