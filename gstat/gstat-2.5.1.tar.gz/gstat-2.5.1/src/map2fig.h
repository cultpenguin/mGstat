int map2fig(int argc, char *argv[]);
