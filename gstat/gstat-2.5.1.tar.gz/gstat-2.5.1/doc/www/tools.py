import glob
import os
import shutil
import tempfile



# exceptions:
executeError = 'command execute error'



def searchAndReplace(search, replace, fnpattern):
  #  1. Glob the fnpattern to concrete filenames.
  #  2. For each filename in the list, call sed to search and replace the
  #     file to a temporary file and move the temporary file to the original.

  fns = glob.glob(fnpattern)                                                # 1.
  if len(fns) == 0:
    raise runExc, 'no file matches pattern \'' + fnpattern + '\''

  tmp = tempfile.mktemp()
  cmd = 'sed \'s/' + search + '/' + replace + '/g\' '

  try:
    for fn in fns:
      c = cmd + fn + ' > ' + tmp
      if os.system(c):
        raise executeError, 'error executing command \'' + c + '\''
      shutil.copyfile(tmp, fn)
    if(os.path.exists(tmp)):
      os.remove(tmp)
  except:
    if(os.path.exists(tmp)):
      os.remove(tmp)
    raise

