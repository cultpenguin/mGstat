import glob
import os
import shutil
import string
import time

import tools

from scriptbase import *



class CreateHtml(ScriptBase):
  def __init__(self, argv):
    self.d_html     = ''
    self.d_template = ''
    self.d_header   = ''
    self.d_footer   = ''
    self.d_index    = ''
    self.d_body     = ''
    ScriptBase.__init__(self, argv)

  def usage(self, argv):
    m = 'usage: ' + os.path.basename(argv[0]) + \
                    ' <html> <template> <header> < footer> <index> <body>'
    self.message(m)

  def parse(self, argv):
    i = len(argv)
    if i < 7:
      raise usageExc, 'not enough arguments'
    if i > 7:
      raise usageExc, 'too many arguments'
    if i == 7:
      self.d_html     = argv[1]
      self.d_template = argv[2]
      self.d_header   = argv[3]
      self.d_footer   = argv[4]
      self.d_index    = argv[5]
      self.d_body     = argv[6]

  def run(self):
    #  1. Open html for writing.
    #  2. Open and read template, header, footer, index and body.

    fhtml     = open(self.d_html,     'w')
    ftemplate = open(self.d_template, 'r')
    fheader   = open(self.d_header,   'r')
    ffooter   = open(self.d_footer,   'r')
    findex    = open(self.d_index,    'r')
    fbody     = open(self.d_body,     'r')

    template  = ftemplate.read()
    ftemplate.close()
    header    = fheader.read()
    fheader.close()
    footer    = ffooter.read()
    ffooter.close()
    index     = findex.read()
    findex.close()
    body      = fbody.read()
    fbody.close()

    # revision  = time.strftime('%y%m%d', time.localtime(time.time()))
    revision  = time.strftime('%B %d, %Y', time.localtime(time.time()))

    html      = template
    # Toplevel replacements.
    html      = string.replace(html, '_body',     body)
    html      = string.replace(html, '_header',   header)
    html      = string.replace(html, '_footer',   footer)
    html      = string.replace(html, '_index',    index)

    # Sublevel replacements.
    html      = string.replace(html, '_revision', revision)

    fhtml.write(html)
    fhtml.close()

