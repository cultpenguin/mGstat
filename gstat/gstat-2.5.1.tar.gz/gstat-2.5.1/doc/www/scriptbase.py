# issues:
#   return value

import os
import sys

# exceptions:
argExc   = 'argument exception'
runExc   = 'runtime exception'
usageExc = 'usage exception'

class ScriptBase:
  def __init__(self, argv):
    try:
      self.parse(argv)
      self.run()
    except usageExc, m:
      self.error(m)
      self.usage(argv)
    except argExc, m:
      self.error(m)
    except runExc, m:
      self.error(m)
    except IOError, detail:
      print detail
      self.error('i/o operation failed: ' + detail[1])
#    except:
#      self.error('unhandled exception')

  def usage(self, argv):
    message('ScriptBase.usage')

  def parse(self, argv):
    message('ScriptBase.parse')

  def run(self):
    message('ScriptBase.run')

  def message(self, m):
    sys.stdout.write(m)
    sys.stdout.write('\n')
    sys.stdout.flush()

  def warning(self, m):
    sys.stdout.write('warning: ')
    sys.stdout.write(m)
    sys.stdout.write('\n')
    sys.stdout.flush()

  def error(self, m):
    sys.stderr.write('error: ')
    sys.stderr.write(m)
    sys.stderr.write('\n')
    sys.stderr.flush()

  def execute(self, c):
    # yepyep: catch errors and raise exeption
    if os.system(c) != 0:
      raise runExc, 'error executing command \'' + c + '\''

